import {View, StyleSheet, Image, Text, ScrollView} from 'react-native';
import { Card } from '@rneui/themed';

const habitaciones = [
  {
    nombre:'Superior King',
    descripcion:'Una estancia confortable, sencilla, aunque dotada de un equipamiento excelente a lo largo de sus 38 m2. Decorada con tonos cálidos y un marcado estilo contemporáneo, la magia la aporta la excelente luz natural que entra por una ventana dotada con excelentes vistas a la ciudad o al volcán',
    imagen: 'https://s7g10.scene7.com/is/image/barcelo/BSSAN_ROOM_22?qlt=75&wid=1200&hei=600&fit=crop,1&fmt=webp-alpha&defaultImage=default-dm&ts=1696256890617'
  },
  {
    nombre:'Premium Level King',
    descripcion:'Una estancia confortable, sencilla, aunque dotada de un equipamiento excelente a lo largo de sus 38 m². Una estancia con un amplio escritorio o un lujoso cuarto de baño revestido de mármol. En esta categoría de habitación los huéspedes tendrán acceso a beneficios adicionales de Premium Level.',
    imagen: 'https://s7g10.scene7.com/is/image/barcelo/BSSAN_ROOM_12?qlt=75&wid=1200&hei=600&fit=crop,1&fmt=webp-alpha&defaultImage=default-dm&ts=1696256972299'
  },
  {
    nombre:'Premium Level Doble',
    descripcion:'Una habitación garante del mejor descanso y del mejor espacio para quienes necesitan visitar el San Salvador por trabajo. A lo largo de sus 38 m², esta habitación cuenta con una decoración armónica potenciada por la luz natural que accede por una ventana que mira al volcán o a la ciudad.',
    imagen: 'https://s7g10.scene7.com/is/image/barcelo/BSSAN_ROOM_10?qlt=75&wid=1200&hei=600&fit=crop,1&fmt=webp-alpha&defaultImage=default-dm&ts=1696257032761'
  },
  {
    nombre:'Suite',
    descripcion:'La mejor habitación del Barceló San Salvador cuenta con el máximo espacio, un total de 80 m², para un descanso sublime entre la decoración más elegante. A las privilegiadas vistas que ofrecen sus ventanales se une un equipamiento de primera categoría.Esta excelente Suite también cuenta con acceso a internet de alta velocidad, despertador y cargador de teléfonos, amplio escritorio con lámpara y servicio de habitaciones 24 horas',
    imagen: 'https://s7g10.scene7.com/is/image/barcelo/BSSAN_ROOM_19?qlt=75&wid=1200&hei=600&fit=crop,1&fmt=webp-alpha&defaultImage=default-dm&ts=1696257087886'
  }
]

const App = () => {


  return(
    <>
      <ScrollView>
      <Text style={styles.Title}>Hotel Barceló</Text>
      <Text style={styles.Title2}>Habitaciones</Text>
        <View style={{width:'100%'}}>
            {habitaciones.map((hab,ind) => {
              return(
                <View key={ind} style={{paddingHorizontal:1}} >
                  <Card>
                  <Card.Title>{hab.nombre}</Card.Title>
                  <Card.Image source={{uri:hab.imagen,}} style={styles.habitaciones} />
                  <Text style={{marginVertical:6}}>{hab.descripcion}</Text>
                </Card>
                </View>
              );
            })}
        </View>

      <Text style={styles.Title2}>Servicios</Text>
      <Card>
        <Card.Title>Strikers Bar & Restaurant</Card.Title>
        
        <Card.Image source={{uri:'https://s7g10.scene7.com/is/image/barcelo/BSSAN_GAST_11?qlt=75&wid=1200&hei=600&fit=crop,1&fmt=webp-alpha&defaultImage=default-dm&ts=1696257352385',}} />
      </Card>
      <Card>
        <Card.Title>Churchill´s Bar</Card.Title>
        <Card.Divider />
        <Card.Image source={{uri:'https://s7g10.scene7.com/is/image/barcelo/BSSAN_GAST_07?qlt=75&wid=1200&hei=600&fit=crop,1&fmt=webp-alpha&defaultImage=default-dm&ts=1696257456195',}} />
      </Card>
      <Card>
        <Card.Title>Garden Court</Card.Title>
        <Card.Divider />
        <Card.Image source={{uri:'https://s7g10.scene7.com/is/image/barcelo/BSSAN_GAST_03-1?qlt=75&wid=1200&hei=600&fit=crop,1&fmt=webp-alpha&defaultImage=default-dm&ts=1696257551343',}} />
      </Card>
      
      <View style={{marginHorizontal:10}}>
      <Text style={styles.Title2}>Lugares para visitar</Text>
      <View style={styles.listado}>
        <View style={styles.listaItem}>
          <Image source={require('./components/img/img1.jpg')} style={styles.mejores} />
        </View>
        <View style={styles.listaItem}>
          <Image source={require('./components/img/img2.jpg')} style={styles.mejores} />
        </View>
        <View style={styles.listaItem}>
          <Image source={require('./components/img/img3.jpg')} style={styles.mejores} />
        </View>
        <View style={styles.listaItem}>
          <Image source={require('./components/img/img4.jpg')} style={styles.mejores} />
        </View>
      </View>
      </View>
      </ScrollView>
      
    </>
  );
};

const styles = StyleSheet.create({
  habitaciones:{
    width: 290,
    height: 200,
    marginRight:10
  },
  listado:{
    flexDirection:'row',
    flexWrap:'wrap',
    justifyContent:'space-between'
  },
  listaItem:{
    flexBasis:'49%'
  },
  mejores:{
    width:'100%',
    height:200,
    marginVertical:5
  },
  Title:{
    fontSize: 22,
    margin: 'auto',
    paddingTop:50,
    paddingLeft:70,
    paddingRight:70,
    fontFamily:"Arial",
    fontWeight: 'bold'
  },
  Title2:{
    fontSize: 19,
    margin: 'auto',
    fontFamily:"Arial",
    fontWeight: 'bold',
    paddingHorizontal: 25,
    paddingVertical:18
  }
});

export default App;